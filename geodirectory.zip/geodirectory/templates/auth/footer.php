<?php
/**
 * Auth footer
 *
 * @author  AyeCode
 * 
 * @version 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
		</div>
	</body>
</html>
