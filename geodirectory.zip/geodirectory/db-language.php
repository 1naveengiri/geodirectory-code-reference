<?php
/**
 * Translate language string stored in database. Ex: Custom Fields
 *
 * @package GeoDirectory
 * @since 2.0.0
 */

// Language keys